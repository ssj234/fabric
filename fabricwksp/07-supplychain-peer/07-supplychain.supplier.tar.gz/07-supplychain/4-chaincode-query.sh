export set FABRIC_CFG_PATH=/home/ssj234/fabricwksp/07-supplychain/peer
export set CORE_PEER_LOCALMSPID=SupplierMSP
export set CORE_PEER_ADDRESS=peer0.supplier.jianshu.com:7051
export set CORE_PEER_MSPCONFIGPATH=/home/ssj234/fabricwksp/07-supplychain/crypto-config/peerOrganizations/supplier.jianshu.com/users/Admin@supplier.jianshu.com/msp

peer chaincode query -C cmbcchannel666 -n testchaincode -v 1.0 -c '{"Args":["query","a"]}'
