export set FABRIC_CFG_PATH=/home/ssj234/fabricwksp/07-supplychain/peer
export set CORE_PEER_LOCALMSPID=CoreMSP
export set CORE_PEER_ADDRESS=peer0.core.jianshu.com:7051
export set CORE_PEER_MSPCONFIGPATH=/home/ssj234/fabricwksp/07-supplychain/crypto-config/peerOrganizations/core.jianshu.com/users/Admin@core.jianshu.com/msp

peer chaincode instantiate -o orderer.jianshu.com:7050 -C cmbcchannel666 -n testchaincode -v 1.0 -c '{"Args":["init","a","100","b","200"]}' -P "AND ('CoreMSP.member','SupplierMSP.member','BankMSP.member')"
