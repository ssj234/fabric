export set FABRIC_CFG_PATH=/home/ssj234/fabricwksp/07-supplychain/peer
export set CORE_PEER_LOCALMSPID=CoreMSP
export set CORE_PEER_ADDRESS=peer0.core.jianshu.com:7051
export set CORE_PEER_MSPCONFIGPATH=/home/ssj234/fabricwksp/07-supplychain/crypto-config/peerOrganizations/core.jianshu.com/users/Admin@core.jianshu.com/msp

peer chaincode install -n supplychain-chaincode -v 1.0 -p github.com/hyperledger/fabric/examples/chaincode/go/supplychain
