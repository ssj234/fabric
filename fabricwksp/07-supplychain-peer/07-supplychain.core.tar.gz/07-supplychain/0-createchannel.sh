export set CORE_PEER_LOCALMSPID=CoreMSP
export set CORE_PEER_MSPCONFIGPATH=/home/ssj234/fabricwksp/07-supplychain/crypto-config/peerOrganizations/core.jianshu.com/users/Admin@core.jianshu.com/msp

peer channel create -t 50 -o orderer.jianshu.com:7050 -c cmbcchannel666 -f /home/ssj234/fabricwksp/07-supplychain/orderer/cmbcchannel666.tx
