export set FABRIC_CFG_PATH=/home/ssj234/fabricwksp/07-supplychain/peer
peer node start >> log_peer.log 2>&1 &
