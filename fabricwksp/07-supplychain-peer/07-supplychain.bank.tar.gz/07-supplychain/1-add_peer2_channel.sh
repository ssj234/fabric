export set FABRIC_CFG_PATH=/home/ssj234/fabricwksp/07-supplychain/peer
export set CORE_PEER_LOCALMSPID=BankMSP
expoer set CORE_PEER_ADDRESS=peer0.bank.jianshu.com:7051
export set CORE_PEER_MSPCONFIGPATH=/home/ssj234/fabricwksp/07-supplychain/crypto-config/peerOrganizations/bank.jianshu.com/users/Admin@bank.jianshu.com/msp

peer channel join -b /home/ssj234/fabricwksp/07-supplychain/cmbcchannel666.block
